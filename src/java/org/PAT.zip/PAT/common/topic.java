package org.PAT.common;

import java.util.ArrayList;
import java.util.HashMap;

import org.PAT.common.MySQL;
public class topic extends MySQL{
	
	public topic(){
		super();
	}
	
	@SuppressWarnings("unchecked")
	public Boolean checkTopic(String topicID){
		String[] fields = {"topic_id"};
		
		ArrayList result = this.query("SELECT * FROM topiclist WHERE topic_id='"+topicID+"'", fields);
		
		if (result.size()>0){
			return true;
		}else{
			return false;
		}
	}
	
	public ArrayList<HashMap<String, String>> getTopic(String topic_id){
		String[] fields = {"topic_id","topic_title","topic_description"};
		
		ArrayList<HashMap<String, String>> result = this.query("SELECT * FROM topiclist WHERE topic_id='"+topic_id + "'", fields);
		
		return result;
	}
	
	public ArrayList<HashMap<String, String>> getCurrentTopicByUser(String user_id){
		String[] fields = {"team_id","topic_id","topic_title"};
		
		ArrayList<HashMap<String, String>> result = this.query("SELECT * FROM current_team_topic WHERE user_id='"+user_id + "'", fields);
		
		return result;
	}

	public ArrayList<HashMap<String, String>> getTopicByUserandSport(String user_id,String sport_id){
		String[] fields = {"topic_id","topic_title"};
		
		ArrayList<HashMap<String, String>> result = this.query("SELECT * FROM refereetopics WHERE user_id='"+user_id + "' AND sport_id="+sport_id, fields);
		
		return result;
	}
	
	public Boolean topicIsAssignedToUser(String userID, String topicID){
		String[] fields = {"topic_id"};
		
		ArrayList<HashMap<String, String>> result = this.query("SELECT * FROM refereetopics WHERE user_id='"+userID + "' AND topic_id='"+topicID+"'", fields);
		
		if (result.size()>0){
			return true;
		}else{
			return false;
		}
	}
	
	
}