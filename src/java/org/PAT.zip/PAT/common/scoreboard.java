package org.PAT.common;

import java.util.ArrayList;
import java.util.HashMap;


import org.PAT.common.MySQL;
public class scoreboard extends MySQL{
	
	public scoreboard(){
		super();
	}
	
	public ArrayList<HashMap<String, String>> getScoreboard(String sport_id){
		String[] fields = {"user_id","sport_id","team_id","referee_name_current_round","referee_name_next_round","score","score_relevant","score_happiness"};
		
		ArrayList<HashMap<String, String>> result = this.query("SELECT * FROM scoreboard WHERE sport_id='"+sport_id + "' ORDER BY team_id, user_id", fields);

		return result;
	}
}