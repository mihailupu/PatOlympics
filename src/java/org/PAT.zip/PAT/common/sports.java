package org.PAT.common;

import java.util.ArrayList;
import java.util.HashMap;

import org.PAT.common.MySQL;
public class sports extends MySQL{
	
	public sports(){
		super();
	}
	
	public Boolean checkSport(String sport_id){
		String[] fields = {"sport_id", "sport_title"};
		
		ArrayList<HashMap<String, String>> result = this.query("SELECT * FROM sports WHERE sport_id= "+sport_id+" AND active=1", fields);
		if (result.size()>0){
			return true;
		}else{
			return false;
		}
	}
	
	public ArrayList<HashMap<String, String>> getList(){
		String[] fields = {"sport_id", "sport_title"};
		
		ArrayList<HashMap<String, String>> result = this.query("SELECT * FROM sports WHERE active=1", fields);
		
		return result;
	}
	
	public ArrayList<HashMap<String, String>> getTopicsByUser(String user_id){
		String[] fields = {"sport_id","topic_id"};
		
		ArrayList<HashMap<String, String>> result = this.query("SELECT * FROM refereetopics WHERE user_id='"+user_id + "' ORDER BY sport_id", fields);
		
		return result;
	}
	
}