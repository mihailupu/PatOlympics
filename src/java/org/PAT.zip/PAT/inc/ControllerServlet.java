package org.PAT.inc;

import java.io.*;
import java.lang.reflect.*;
import java.util.Date;

import javax.servlet.*;
import javax.servlet.http.*;
import org.json.simple.JSONObject;

public class ControllerServlet extends HttpServlet {
	protected JSONObject outputObj;
	protected HttpSession pageSession;
	private static final long serialVersionUID = 1L;

	public ControllerServlet() {
        super();        
    }
    
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        doGet(req, resp);
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {	    	    	
		pageSession = request.getSession(true);
    	Config.init(getServletContext());
    	outputObj = new JSONObject();
    	
        Method actionMethod;
        try {
            actionMethod =
                    getClass().getMethod("pageAction",
                    new Class[]{HttpServletRequest.class, HttpServletResponse.class});
        } catch (NoSuchMethodException e) {
            throw new ServletException("Unknown action: pageAction");
        }

        try {
            actionMethod.invoke(this, new Object[]{request, response});
        } catch (IllegalAccessException e) {
            throw new ServletException(e);
        } catch (InvocationTargetException e) {
            throw new ServletException(e.getTargetException());
        }
        
        response.setContentType("text/html");
        java.io.PrintWriter out = response.getWriter();
        
        out.println(outputObj);
        out.close();
    }
	
	public boolean isLogin(HttpServletRequest request){
    	boolean result;
    	if ((pageSession.getAttribute("isLogin") == null)||(!(Boolean)pageSession.getAttribute("isLogin"))){
    		result = false;
    	}else{
    		Date d = new Date();
			pageSession.setAttribute("loginTime", d);
    		pageSession.setAttribute("isLogin", true);
    		result = true;
    	}
    	return result;
    	
    }
}