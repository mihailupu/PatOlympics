package org.PAT.web;

import javax.servlet.http.*;

import org.PAT.common.docid;
import org.PAT.inc.ControllerTemplate;
import org.PAT.inc.Page;


public class AdminServlet extends ControllerTemplate {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void indexAction(HttpServletRequest req, HttpServletResponse resp,
			Page p) {
		
		docid docObj = new docid();
		p.put("listDoc", docObj.getDocIDs());
		
		p.setTemplate("index.html");
	}

}
