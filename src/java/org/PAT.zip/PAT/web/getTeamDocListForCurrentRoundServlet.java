package org.PAT.web;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.PAT.common.rounds;
import org.PAT.inc.ControllerServlet;

/**
 * Servlet implementation class excelSevlet
 */
public class getTeamDocListForCurrentRoundServlet extends ControllerServlet {
	private static final long serialVersionUID = 1L;

	@SuppressWarnings("unchecked")
	public void pageAction(HttpServletRequest request, HttpServletResponse response){
		rounds roundObj = new rounds();
    	String Order = request.getParameter("sort_on");
    	String sessionID = request.getParameter("session_id");
    	if ((sessionID!= null)&&(pageSession.getId().compareTo(sessionID)==0)&&(pageSession.getAttribute("userID")!=null)){
    		if (pageSession.getAttribute("user_role").toString().compareTo("TEAM")==0){
	    		ArrayList<HashMap<String, String>> rows = roundObj.getDoclistSubmitinCurrentRound(pageSession.getAttribute("userID").toString(), Order);
				if (rows.size()>0){
					LinkedList<Object> listTopic = new LinkedList<Object>();
					LinkedList<String> itemTopic;
					for (int i=0;i<rows.size();i++){
		    	    	itemTopic = new LinkedList<String>();
		    	    	itemTopic.add(rows.get(i).get("doc_id"));
		    	    	itemTopic.add(rows.get(i).get("doc_title"));
		    	    	itemTopic.add(rows.get(i).get("submittime"));
		    	    	
		    	    	listTopic.add(itemTopic);
					}
	    	    	outputObj.put("value", listTopic);
	    			outputObj.put("error", "");
				}else{
					outputObj.put("value", "");
					if (roundObj.userInCurrentRound(pageSession.getAttribute("userID").toString())){
						outputObj.put("error", "");
					}else{
						outputObj.put("error", "ERROR_NOTOPIC");
					}
				}
    		}else{
        		outputObj.put("value", "");
    			outputObj.put("error", "ERROR_NOTEAM");
        	}
    	}else{
    		outputObj.put("value", "");
			outputObj.put("error", "ERROR_INVALIDSESSION");
    	}
    	
	}

}
