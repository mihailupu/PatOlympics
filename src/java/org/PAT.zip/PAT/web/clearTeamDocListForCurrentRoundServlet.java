package org.PAT.web;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.PAT.common.docid;
import org.PAT.common.rounds;
import org.PAT.common.topic;
import org.PAT.common.user;
import org.PAT.inc.ControllerServlet;

/**
 * Servlet implementation class excelSevlet
 */
public class clearTeamDocListForCurrentRoundServlet extends ControllerServlet {
	private static final long serialVersionUID = 1L;

	@SuppressWarnings("unchecked")
	public void pageAction(HttpServletRequest request, HttpServletResponse response){
		String sessionID = request.getParameter("session_id");
                user userObj = new user();
    	//if ((sessionID!= null)&&(pageSession.getId().compareTo(sessionID)==0)&&(pageSession.getAttribute("userID")!=null)){
        if ((sessionID!= null)){

    		if (userObj.getRoleBySession(sessionID).compareTo("TEAM")==0){
    			
    			//String userID = pageSession.getAttribute("userID").toString();
                        String userID=userObj.getUserIDBySession(sessionID);
    			topic topObj = new topic();
    			ArrayList<HashMap<String, String>> topicObj = topObj.getCurrentTopicByUser(userID);
    			
    			rounds roundObj = new rounds();
    			ArrayList<HashMap<String, String>> rObj = roundObj.getCurrentRound();
    			
    			if ((roundObj.userInCurrentRound(userID))&&(rObj.size()>0)){
    				Date date = new Date();
	    			
	    			if (roundObj.currentRoundinTime(date.getTime())){
	    				if (topicObj.size()>0){
		        			docid docObj = new docid();
	    					int numOfDel = docObj.clearDoc(userID,rObj.get(0).get("round_id"),topicObj.get(0).get("topic_id"));
	        				outputObj.put("value", numOfDel);
	        				outputObj.put("error", "");
	    				}else{
	    					outputObj.put("value", "");
	        				outputObj.put("error", "ERROR_NOTOPIC");
	    				}
	    			}else{
    					outputObj.put("value", "");
        				outputObj.put("error", "ERROR_NOTINTIME");
    				}
    			}else{
    				outputObj.put("value", "");
    				outputObj.put("error", "ERROR_NOROUND");
    			}
    			
    		}else{
        		outputObj.put("value", "");
    			outputObj.put("error", "ERROR_NOTEAM");
        	}
    	}else{
    		outputObj.put("value", "");
			outputObj.put("error", "ERROR_INVALIDSESSION");
    	}
    	
	}

}
