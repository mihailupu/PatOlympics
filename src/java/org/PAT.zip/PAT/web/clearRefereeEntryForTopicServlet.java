package org.PAT.web;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.PAT.common.docid;
import org.PAT.common.rounds;
import org.PAT.common.topic;
import org.PAT.inc.ControllerServlet;

/**
 * Servlet implementation class excelSevlet
 */
public class clearRefereeEntryForTopicServlet extends ControllerServlet {
	private static final long serialVersionUID = 1L;

	@SuppressWarnings("unchecked")
	public void pageAction(HttpServletRequest request, HttpServletResponse response){
		String sessionID = request.getParameter("session_id");
		String topic_id = request.getParameter("topic_id");
		topic topicObj = new topic();
    	if ((sessionID!= null)&&(pageSession.getId().compareTo(sessionID)==0)&&(pageSession.getAttribute("userID")!=null)){
    		if (pageSession.getAttribute("user_role").toString().compareTo("REFEREE")==0){
    			if (topic_id!=null){
	    			if (topicObj.topicIsAssignedToUser(pageSession.getAttribute("userID").toString(),topic_id)){
		    			String userID = pageSession.getAttribute("userID").toString();
		    			
		    			rounds roundObj = new rounds();
		    			ArrayList<HashMap<String, String>> rObj = roundObj.getCurrentRound();
		    			Date date = new Date();
		    			
		    			if (roundObj.currentRoundinTime(date.getTime())){
		    				String doc_id = request.getParameter("doc_id");
		        			docid docObj = new docid();
		        			if ((doc_id != null)&&(docObj.checkDoc(doc_id))){
	        					docObj.clearDoc(userID,rObj.get(0).get("round_id"),topic_id,doc_id);
		        				outputObj.put("value", true);
		        				outputObj.put("error", "");
		        			}else{
		        				outputObj.put("value", false);
		        				outputObj.put("error", "");
		        			}
		    			}else{
		    				outputObj.put("value", "");
							outputObj.put("error", "ERROR_NOTINTIME");
		    			}
	    			}else{
	    				outputObj.put("value", "");
						outputObj.put("error", "ERROR_NOTASSIGNED");
	    			}
    			}else{
					outputObj.put("value", "");
    				outputObj.put("error", "ERROR_NOTOPIC");
    			}
    		}else{
        		outputObj.put("value", "");
    			outputObj.put("error", "ERROR_NOREFEREE");
        	}
    	}else{
    		outputObj.put("value", "");
			outputObj.put("error", "ERROR_INVALIDSESSION");
    	}
    	
	}

}
