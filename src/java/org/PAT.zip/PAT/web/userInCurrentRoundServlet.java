package org.PAT.web;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.PAT.common.rounds;
import org.PAT.inc.ControllerServlet;

/**
 * Servlet implementation class excelSevlet
 */
public class userInCurrentRoundServlet extends ControllerServlet {
	private static final long serialVersionUID = 1L;

	@SuppressWarnings("unchecked")
	public void pageAction(HttpServletRequest request, HttpServletResponse response){
		rounds roundObj = new rounds();
    	
		String sessionID = request.getParameter("session_id");
    	if ((sessionID!= null)&&(pageSession.getId().compareTo(sessionID)==0)&&(pageSession.getAttribute("userID")!=null)){
	    	outputObj.put("value", roundObj.userInCurrentRound(pageSession.getAttribute("userID").toString()));
			outputObj.put("error", "");
    	}else{
    		outputObj.put("value", "");
			outputObj.put("error", "ERROR_INVALIDSESSION");
    	}
	}
}
