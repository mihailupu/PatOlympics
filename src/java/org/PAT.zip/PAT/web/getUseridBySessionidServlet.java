package org.PAT.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.PAT.inc.ControllerServlet;

/**
 * Servlet implementation class excelSevlet
 */
public class getUseridBySessionidServlet extends ControllerServlet {
	private static final long serialVersionUID = 1L;

	@SuppressWarnings("unchecked")
	public void pageAction(HttpServletRequest request, HttpServletResponse response){
    	String sessionID = request.getParameter("session_id");
    	if ((sessionID!= null)&&(pageSession.getId().compareTo(sessionID)==0)){
    		if ((pageSession.getAttribute("isLogin")!= null)&&((Boolean)pageSession.getAttribute("isLogin"))){
    			outputObj.put("value", pageSession.getAttribute("userID").toString());
    			outputObj.put("error", "");
    		}else{
    			outputObj.put("value", "");
    			outputObj.put("error", "ERROR_INVALIDSESSION");
    		}
		}else{
			outputObj.put("value", "");
			outputObj.put("error", "ERROR_INVALIDSESSION");
		}
	}

}
