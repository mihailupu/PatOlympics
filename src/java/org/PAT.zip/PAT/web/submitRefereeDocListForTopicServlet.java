package org.PAT.web;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.PAT.common.docid;
import org.PAT.common.rounds;
import org.PAT.common.topic;
import org.PAT.inc.ControllerServlet;

/**
 * Servlet implementation class excelSevlet
 */
public class submitRefereeDocListForTopicServlet extends ControllerServlet {
	private static final long serialVersionUID = 1L;

	@SuppressWarnings("unchecked")
	public void pageAction(HttpServletRequest request, HttpServletResponse response){
		String sessionID = request.getParameter("session_id");
		String topic_id = request.getParameter("topic_id");
		topic topicObj = new topic();
    	if ((sessionID!= null)&&(pageSession.getId().compareTo(sessionID)==0)&&(pageSession.getAttribute("userID")!=null)){
    		if (pageSession.getAttribute("user_role").toString().compareTo("REFEREE")==0){
    			if (topic_id!=null){
	    			if (topicObj.topicIsAssignedToUser(pageSession.getAttribute("userID").toString(),topic_id)){
		    			String userID = pageSession.getAttribute("userID").toString();
		    			
		    			rounds roundObj = new rounds();
		    			ArrayList<HashMap<String, String>> rObj = roundObj.getCurrentRound();
		    			Date date = new Date();
		    			
		    			if (roundObj.currentRoundinTime(date.getTime())){
		    				String doclist = request.getParameter("doclist");
		    				
		    				String submitTime = String.valueOf(date.getTime());
		        			String docid = "";
		        			docid docObj = new docid();
		        			int numOfSubmit = 0;
		        			if (doclist != null){
		        				if (doclist.startsWith("||")){
		        					doclist = doclist.substring(2);
		        				}
		        				if (doclist.endsWith("||")){
		        					doclist = doclist.substring(0,doclist.length()-2);
		        				}
		        				        				
		        				while (doclist.indexOf("||")>=0){
		        					docid = doclist.substring(0,doclist.indexOf("||"));
		        					doclist = doclist.substring(doclist.indexOf("||")+2);
		        					if ((docObj.checkDoc(docid))&&(!docObj.checkSubmitList(userID,rObj.get(0).get("round_id"),topic_id,docid))){
		        						docObj.insertDoc(userID,rObj.get(0).get("round_id"),topic_id,docid,submitTime);
		        						numOfSubmit++;
		        					}
		        				}
		        				if ((!doclist.isEmpty())&&(!docObj.checkSubmitList(userID,rObj.get(0).get("round_id"),topic_id,doclist))){
		        					if (docObj.checkDoc(doclist)){
		        						docObj.insertDoc(userID,rObj.get(0).get("round_id"),topic_id,doclist,submitTime);
		        						numOfSubmit++;
		        					}
		        				}
		        				outputObj.put("value", numOfSubmit);
		        				outputObj.put("error", "");
		        			}else{
		        				outputObj.put("value", "");
		        				outputObj.put("error", "ERROR_NOTADDED");
		        			}
		    			}else{
	        				outputObj.put("value", "");
	        				outputObj.put("error", "ERROR_NOTINTIME");
	        			}
	    			
	    			}else{
	    				outputObj.put("value", "");
						outputObj.put("error", "ERROR_NOTASSIGNED");
	    			}
    			}else{
					outputObj.put("value", "");
    				outputObj.put("error", "ERROR_NOTOPIC");
    			}
    		}else{
        		outputObj.put("value", "");
    			outputObj.put("error", "ERROR_NOREFEREE");
        	}
    	}else{
    		outputObj.put("value", "");
			outputObj.put("error", "ERROR_INVALIDSESSION");
    	}
	}

}
